import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
export default function ResetPassword() { const [, setLocation] = useLocation(); const token=new URLSearchParams(window.location.search).get("token")||""; const [password,setPassword]=useState(""); const reset=trpc.auth.resetPassword.useMutation({onSuccess:()=>{toast.success("Password updated.");setLocation("/auth");},onError:e=>toast.error(e.message)}); return <main className="min-h-screen bg-[#fff8fc] flex items-center justify-center p-6"><div className="w-full max-w-md rounded-3xl bg-white p-8 shadow-xl"><p className="eyebrow">Account recovery</p><h1 className="mt-3 font-serif text-3xl">Choose a new password</h1><Input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="10+ chars, upper/lowercase and number" className="mt-6"/><Button onClick={()=>reset.mutate({token,password})} disabled={reset.isPending||!token} className="mt-4 w-full rounded-xl bg-[#b96eaa]">Update password</Button></div></main>; }
