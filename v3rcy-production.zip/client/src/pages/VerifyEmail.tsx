import { useEffect } from "react";
import { useLocation } from "wouter";
import { CheckCircle2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
export default function VerifyEmail() { const [, setLocation] = useLocation(); const token = new URLSearchParams(window.location.search).get("token") || ""; const verify = trpc.auth.verifyEmail.useMutation({ onSuccess:()=>{toast.success("Email verified.");setLocation("/auth");}, onError:e=>toast.error(e.message)}); useEffect(()=>{ if(token) verify.mutate({token}); },[]); return <main className="min-h-screen bg-[#fff8fc] flex items-center justify-center p-6"><div className="rounded-3xl bg-white p-10 text-center shadow-xl"><CheckCircle2 className="mx-auto h-12 w-12 text-[#b96eaa]"/><h1 className="mt-4 font-serif text-3xl">Verifying your email…</h1><p className="mt-3 text-sm text-[#806d85]">You can return to sign in when verification finishes.</p></div></main>; }
