import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { LockKeyhole, Mail, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function Auth() {
  const [, setLocation] = useLocation();
  const [mode, setMode] = useState<"login" | "register" | "forgot">("login");
  const [email, setEmail] = useState(""); const [password, setPassword] = useState(""); const [name, setName] = useState("");
  const register = trpc.auth.register.useMutation({ onSuccess: result => { toast.success("Account created. Check your email to verify it."); if (result.checkoutUrl) window.location.href = result.checkoutUrl; else setLocation("/"); } });
  const login = trpc.auth.login.useMutation({ onSuccess: () => { toast.success("Welcome back."); setLocation("/"); } });
  const forgot = trpc.auth.requestReset.useMutation({ onSuccess: () => toast.success("If that email exists, a reset link has been sent.") });
  const user = trpc.auth.me.useQuery();
  const registrationInfo = trpc.auth.registrationInfo.useQuery();
  useEffect(() => { if (user.data) setLocation("/"); }, [user.data, setLocation]);
  const busy = register.isPending || login.isPending || forgot.isPending;
  return <main className="min-h-screen bg-[radial-gradient(circle_at_15%_15%,#f9d8ef,transparent_35%),radial-gradient(circle_at_85%_10%,#e5d9ff,transparent_30%),#fff8fc] px-5 py-10 text-[#3e2b45]">
    <div className="mx-auto grid max-w-5xl overflow-hidden rounded-[2rem] border border-white/80 bg-white/80 shadow-[0_30px_100px_rgba(130,80,130,.16)] backdrop-blur-xl md:grid-cols-[1fr_.9fr]">
      <section className="hidden bg-gradient-to-br from-[#f8d9ed] via-[#eadcfb] to-[#f5e6f3] p-12 md:flex md:flex-col md:justify-between"><div><div className="flex items-center gap-2 font-serif text-2xl"><Sparkles className="h-5 w-5 text-[#a65b9b]"/>V3rya</div><p className="eyebrow mt-12">A softer social space</p><h1 className="mt-4 font-serif text-5xl leading-tight">Meet people. Share moments. Stay connected.</h1><p className="mt-6 max-w-md leading-7 text-[#705d76]">A private community with a friendly feed, expressive reactions, thoughtful comments, and real moderation.</p></div><p className="text-sm text-[#806d85]">18+ community · Paid membership · Email/password accounts</p></section>
      <section className="p-7 sm:p-10"><button onClick={() => setLocation("/")} className="font-serif text-xl md:hidden">V3rya</button><p className="eyebrow mt-6">{mode === "login" ? "Welcome back" : mode === "register" ? "Join the community" : "Account recovery"}</p><h2 className="mt-3 font-serif text-4xl">{mode === "login" ? "Sign in" : mode === "register" ? "Create your account" : "Reset your password"}</h2>
      <div className="mt-7 space-y-4">{mode === "register" && <div><Label>Name</Label><Input value={name} onChange={e=>setName(e.target.value)} placeholder="Your name" className="mt-2 bg-white"/></div>}<div><Label>Email</Label><Input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" className="mt-2 bg-white"/></div>{mode !== "forgot" && <div><Label>Password</Label><Input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="10+ chars, upper/lowercase and number" className="mt-2 bg-white"/></div>}
      <Button disabled={busy} onClick={()=> mode === "login" ? login.mutate({email,password}) : mode === "register" ? register.mutate({email,password,name}) : forgot.mutate({email})} className="h-12 w-full rounded-xl bg-[#b96eaa] text-white hover:bg-[#a85c9a]">{mode === "login" ? <><LockKeyhole className="mr-2 h-4 w-4"/>Sign in</> : mode === "register" ? "Continue to membership" : <><Mail className="mr-2 h-4 w-4"/>Send reset link</>}</Button>
      {mode === "register" && <p className="text-xs leading-5 text-[#806d85]">{registrationInfo.data ? `A one-time membership registration payment of ${(registrationInfo.data.amountCents / 100).toFixed(2)} ${registrationInfo.data.currency.toUpperCase()} is required before your account can become active.` : "Membership payment is required before your account can become active."} You will also need to verify your email.</p>}</div>
      <div className="mt-6 flex flex-wrap gap-3 text-sm">{mode !== "login" && <button onClick={()=>setMode("login")} className="text-[#9a5590]">Already have an account?</button>}{mode === "login" && <><button onClick={()=>setMode("register")} className="text-[#9a5590]">Create an account</button><button onClick={()=>setMode("forgot")} className="text-[#806d85]">Forgot password?</button></>}{mode === "forgot" && <button onClick={()=>setMode("login")} className="text-[#9a5590]">Back to sign in</button>}</div>
      </section>
    </div>
  </main>;
}
