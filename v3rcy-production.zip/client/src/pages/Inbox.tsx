import { LockKeyhole, MessageCircle, Send } from "lucide-react";
import { useMemo, useState } from "react";
import SiteHeader from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Inbox() {
  const { isAuthenticated, loading } = useAuth();
  const params = useMemo(() => new URLSearchParams(window.location.search), []);
  const contactId = Number(params.get("to") || 0);
  const contactName = params.get("name") || "Private member";
  const inbox = trpc.messaging.inbox.useQuery(undefined, { enabled: isAuthenticated });
  const [selectedId, setSelectedId] = useState<number | undefined>();
  const effectiveId = selectedId || inbox.data?.[0]?.id;
  const messages = trpc.messaging.messages.useQuery({ conversationId: effectiveId || 1 }, { enabled: Boolean(effectiveId) && isAuthenticated });
  const [draft, setDraft] = useState("");
  const send = trpc.messaging.send.useMutation({ onSuccess: () => { setDraft(""); inbox.refetch(); messages.refetch(); toast.success("Message sent privately."); }, onError: (error) => toast.error(error.message) });
  if (loading) return <div className="min-h-screen bg-[#080d1d]" />;
  if (!isAuthenticated) return <div className="min-h-screen bg-[#080d1d] text-white"><SiteHeader /><main className="container py-20"><div className="mx-auto max-w-xl rounded-[1.5rem] border border-white/10 bg-[#0c1326] p-8 text-center"><LockKeyhole className="mx-auto h-6 w-6 text-[#e1c687]" /><h1 className="mt-5 font-serif text-4xl">Messages stay between members.</h1><p className="mt-3 text-slate-400">Sign in to use private conversation threads.</p><Button onClick={() => startLogin()} className="mt-7 rounded-xl bg-[#e1c687] text-[#10172c] hover:bg-[#f0da9f]">Sign in to continue</Button></div></main></div>;
  const recipientId = contactId || inbox.data?.find((thread) => thread.id === effectiveId)?.otherUserId;
  const recipientName = contactId ? contactName : inbox.data?.find((thread) => thread.id === effectiveId)?.otherDisplayName || "Private member";
  return <div className="min-h-screen bg-[#080d1d] text-white"><SiteHeader /><main className="container py-10 sm:py-14"><div className="mb-8"><p className="eyebrow">Private threads</p><h1 className="mt-3 font-serif text-4xl sm:text-5xl">Messages</h1><p className="mt-3 max-w-2xl text-sm leading-6 text-slate-400">Conversation access is limited to the members in each thread. Messages are not end-to-end encrypted in this release.</p></div><section className="grid min-h-[570px] overflow-hidden rounded-[1.5rem] border border-white/10 bg-[#0c1326] lg:grid-cols-[300px_1fr]"><aside className="border-b border-white/8 p-4 lg:border-r lg:border-b-0"><p className="px-2 pb-3 text-xs font-medium tracking-[.16em] text-slate-500 uppercase">Conversations</p>{inbox.data?.length ? <div className="space-y-2">{inbox.data.map((thread) => <button key={thread.id} onClick={() => setSelectedId(thread.id)} className={`w-full rounded-xl p-3 text-left transition ${effectiveId === thread.id ? "bg-white/9" : "hover:bg-white/[.04]"}`}><p className="truncate text-sm font-medium">{thread.otherDisplayName || "Private member"}</p><p className="mt-1 truncate text-xs text-slate-500">{thread.latestMessage?.body || "No messages yet"}</p></button>)}</div> : <p className="px-2 pt-4 text-sm leading-6 text-slate-500">No conversations yet. Connect from a listing when both members are verified.</p>}</aside><div className="flex min-h-[480px] flex-col"><div className="flex items-center gap-3 border-b border-white/8 p-5"><span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#e1c687]/10 text-[#e1c687]"><MessageCircle className="h-4 w-4" /></span><div><p className="font-medium">{recipientName}</p><p className="text-xs text-slate-500">Private member thread</p></div></div><div className="flex-1 space-y-3 p-5">{effectiveId && messages.data?.map((message) => <div key={message.id} className="max-w-[80%] rounded-2xl bg-white/[.06] px-4 py-3 text-sm leading-6 text-slate-200">{message.body}</div>)}{!effectiveId && !contactId && <div className="flex h-full items-center justify-center text-center text-sm text-slate-500">Select a conversation or begin one from a listing.</div>}{contactId && !effectiveId && <div className="flex h-full items-center justify-center text-center text-sm leading-6 text-slate-500">Start a considered conversation with {contactName}. Verification is required before a message can be sent.</div>}</div><div className="border-t border-white/8 p-4"><div className="flex gap-3"><Textarea value={draft} onChange={(event) => setDraft(event.target.value)} placeholder={recipientId ? "Write a private message" : "Choose a conversation first"} disabled={!recipientId} className="min-h-11 border-white/10 bg-[#080d1d] text-white placeholder:text-slate-600" /><Button disabled={!recipientId || !draft.trim() || send.isPending} onClick={() => recipientId && send.mutate({ recipientUserId: recipientId, body: draft })} className="h-11 self-end rounded-xl bg-[#e1c687] text-[#10172c] hover:bg-[#f0da9f]"><Send className="h-4 w-4" /></Button></div></div></div></section></main></div>;
}
