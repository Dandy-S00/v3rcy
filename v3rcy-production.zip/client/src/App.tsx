import AgeGate from "@/components/AgeGate";
import SeoHead from "@/components/SeoHead";
import AdminStudio from "@/pages/AdminStudio";
import Auth from "@/pages/Auth";
import Browse from "@/pages/Browse";
import CityGuides from "@/pages/CityGuides";
import Feed from "@/pages/Feed";
import Inbox from "@/pages/Inbox";
import ListingDetail from "@/pages/ListingDetail";
import MemberProfile from "@/pages/MemberProfile";
import NotFound from "@/pages/NotFound";
import PostListing from "@/pages/PostListing";
import Profile from "@/pages/Profile";
import ReportListing from "@/pages/ReportListing";
import ResetPassword from "@/pages/ResetPassword";
import SafetyCenter from "@/pages/SafetyCenter";
import VerifyEmail from "@/pages/VerifyEmail";
import PaymentResult from "@/pages/PaymentResult";
import Home from "./pages/Home";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

function Router() {
  const [location] = useLocation(); const reduceMotion = useReducedMotion(); const transition = reduceMotion ? { duration: 0 } : { duration: 0.22, ease: "circOut" as const };
  return <AnimatePresence mode="wait" initial={false}><motion.div key={location} initial={reduceMotion ? false : { opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={reduceMotion ? undefined : { opacity: 0, y: -5 }} transition={transition}><Switch>
    <Route path="/" component={Home} /><Route path="/auth" component={Auth} /><Route path="/auth/verify" component={VerifyEmail} /><Route path="/auth/reset" component={ResetPassword} /><Route path="/auth/payment-success" component={PaymentResult} /><Route path="/auth/payment-cancelled" component={() => <PaymentResult cancel />} />
    <Route path="/feed" component={Feed} /><Route path="/browse" component={Browse} /><Route path="/guides" component={CityGuides} /><Route path="/listing/:id" component={ListingDetail} /><Route path="/profile" component={Profile} /><Route path="/member/:id" component={MemberProfile} /><Route path="/post" component={PostListing} /><Route path="/inbox" component={Inbox} /><Route path="/report/listing/:id" component={ReportListing} /><Route path="/safety" component={SafetyCenter} /><Route path="/studio" component={AdminStudio} /><Route path="/404" component={NotFound} /><Route component={NotFound} />
  </Switch></motion.div></AnimatePresence>;
}
export default function App(){ return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster/><AgeGate><SeoHead/><Router/></AgeGate></TooltipProvider></ThemeProvider></ErrorBoundary>; }
