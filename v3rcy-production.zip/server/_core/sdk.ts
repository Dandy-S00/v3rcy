import crypto from "node:crypto";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { ForbiddenError } from "@shared/_core/errors";
import type { Request } from "express";
import { SignJWT, jwtVerify } from "jose";
import type { User } from "../../drizzle/schema";
import * as db from "../db";
import { ENV } from "./env";

const secret = () => {
  if (!ENV.cookieSecret) throw new Error("JWT_SECRET is not configured");
  return new TextEncoder().encode(ENV.cookieSecret);
};

export type SessionPayload = { userId: number; tokenId: string };

export async function hashPassword(password: string): Promise<string> {
  const salt = crypto.randomBytes(16);
  const derived = await new Promise<Buffer>((resolve, reject) => crypto.scrypt(password, salt, 64, { N: 16384, r: 8, p: 1 }, (error, key) => error ? reject(error) : resolve(key)));
  return `scrypt$16384$8$1$${salt.toString("base64url")}$${derived.toString("base64url")}`;
}

export async function verifyPassword(password: string, encoded: string): Promise<boolean> {
  const [scheme, n, r, p, saltText, hashText] = encoded.split("$");
  if (scheme !== "scrypt" || !n || !r || !p || !saltText || !hashText) return false;
  const salt = Buffer.from(saltText, "base64url");
  const expected = Buffer.from(hashText, "base64url");
  const actual = await new Promise<Buffer>((resolve, reject) => crypto.scrypt(password, salt, expected.length, { N: Number(n), r: Number(r), p: Number(p) }, (error, key) => error ? reject(error) : resolve(key)));
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

export function passwordIsStrong(password: string) {
  return password.length >= 10 && /[a-z]/.test(password) && /[A-Z]/.test(password) && /\d/.test(password);
}

export async function createSessionToken(userId: number, expiresInMs = ONE_YEAR_MS): Promise<string> {
  return new SignJWT({ userId, tokenId: crypto.randomUUID() })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setIssuedAt()
    .setExpirationTime(Math.floor((Date.now() + expiresInMs) / 1000))
    .sign(secret());
}

export async function verifySession(token: string | undefined | null): Promise<number | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret(), { algorithms: ["HS256"] });
    return typeof payload.userId === "number" ? payload.userId : null;
  } catch {
    return null;
  }
}

function parseCookies(header: string | undefined) {
  const result = new Map<string, string>();
  if (!header) return result;
  for (const part of header.split(";")) {
    const index = part.indexOf("=");
    if (index > 0) result.set(part.slice(0, index).trim(), decodeURIComponent(part.slice(index + 1).trim()));
  }
  return result;
}

export type AuthenticatedUser = User;

class SDKServer {
  async authenticateRequest(req: Request): Promise<AuthenticatedUser> {
    const token = parseCookies(req.headers.cookie).get(COOKIE_NAME);
    const userId = await verifySession(token);
    if (!userId) throw ForbiddenError("Invalid session");
    const user = await db.getUserById(userId);
    if (!user || user.membershipStatus !== "active" || user.accountStatus === "suspended") throw ForbiddenError("Account is not active");
    return user;
  }
}

export const sdk = new SDKServer();
