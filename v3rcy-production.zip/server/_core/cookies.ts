import type { CookieOptions } from "express";
import { ENV } from "./env";

export function getSessionCookieOptions(req?: { protocol?: string }): CookieOptions {
  return {
    httpOnly: true,
    secure: ENV.isProduction || req?.protocol === "https",
    sameSite: "lax",
    path: "/",
    maxAge: 1000 * 60 * 60 * 24 * 30,
  };
}
