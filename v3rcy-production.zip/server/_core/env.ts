export const ENV = {
  appUrl: process.env.APP_URL ?? "http://localhost:3000",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  adminEmail: (process.env.ADMIN_EMAIL ?? "").trim().toLowerCase(),
  registrationFeeCents: Number(process.env.REGISTRATION_FEE_CENTS ?? 999),
  stripeSecretKey: process.env.STRIPE_SECRET_KEY ?? "",
  stripeWebhookSecret: process.env.STRIPE_WEBHOOK_SECRET ?? "",
  stripeCurrency: (process.env.STRIPE_CURRENCY ?? "usd").toLowerCase(),
  resendApiKey: process.env.RESEND_API_KEY ?? "",
  emailFrom: process.env.EMAIL_FROM ?? "V3rya <noreply@example.com>",
  s3Bucket: process.env.S3_BUCKET ?? "",
  s3Region: process.env.S3_REGION ?? process.env.AWS_REGION ?? "us-east-1",
  s3Endpoint: process.env.S3_ENDPOINT ?? "",
  s3PublicBaseUrl: process.env.S3_PUBLIC_BASE_URL ?? "",
  isProduction: process.env.NODE_ENV === "production",
};

export function assertProductionConfig() {
  if (!ENV.isProduction) return;
  const required: Array<[string, string]> = [
    ["DATABASE_URL", ENV.databaseUrl],
    ["JWT_SECRET", ENV.cookieSecret],
    ["APP_URL", ENV.appUrl],
    ["ADMIN_EMAIL", ENV.adminEmail],
    ["STRIPE_SECRET_KEY", ENV.stripeSecretKey],
    ["STRIPE_WEBHOOK_SECRET", ENV.stripeWebhookSecret],
    ["S3_BUCKET", ENV.s3Bucket],
    ["S3_REGION", ENV.s3Region],
    ["S3_PUBLIC_BASE_URL", ENV.s3PublicBaseUrl],
  ];
  const missing = required.filter(([, value]) => !value).map(([name]) => name);
  if (missing.length) throw new Error(`Missing production environment variables: ${missing.join(", ")}`);
  if (ENV.cookieSecret.length < 32) throw new Error("JWT_SECRET must be at least 32 characters in production.");
  if (!Number.isInteger(ENV.registrationFeeCents) || ENV.registrationFeeCents < 50) throw new Error("REGISTRATION_FEE_CENTS must be an integer of at least 50.");
}
