import type { Express } from "express";

export function registerStorageProxy(_app: Express) {
  // Object storage is served directly from the configured public bucket/CDN.
}
