import crypto from "node:crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import * as db from "./db";
import { createSessionToken, hashPassword, passwordIsStrong, verifyPassword } from "./_core/sdk";
import { ENV } from "./_core/env";
import { createRegistrationCheckout } from "./payment";

const emailSchema = z.string().trim().toLowerCase().email().max(320);
const tokenHash = (token: string) => crypto.createHash("sha256").update(token).digest("hex");
const createToken = () => crypto.randomBytes(32).toString("base64url");
const authAttempts = new Map<string, { count: number; resetAt: number }>();
function enforceAuthRateLimit(key: string, maximum = 10) { const now = Date.now(); const current = authAttempts.get(key); if (!current || current.resetAt <= now) { authAttempts.set(key, { count: 1, resetAt: now + 15 * 60 * 1000 }); return; } if (current.count >= maximum) throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Too many authentication attempts. Please try again later." }); current.count += 1; }

async function sendEmail(to: string, subject: string, html: string) {
  if (!ENV.resendApiKey) {
    if (ENV.isProduction) throw new Error("Email delivery is not configured.");
    console.log(`[Email preview] ${to}: ${subject}\n${html}`);
    return;
  }
  const response = await fetch("https://api.resend.com/emails", { method: "POST", headers: { Authorization: `Bearer ${ENV.resendApiKey}`, "Content-Type": "application/json" }, body: JSON.stringify({ from: ENV.emailFrom, to: [to], subject, html }) });
  if (!response.ok) throw new Error(`Email provider rejected the message (${response.status}).`);
}

export async function sendVerificationEmail(user: { id: number; email: string }) {
  const raw = createToken();
  await db.createEmailToken({ userId: user.id, tokenHash: tokenHash(raw), type: "verify", expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24) });
  const url = `${ENV.appUrl.replace(/\/$/, "")}/auth/verify?token=${encodeURIComponent(raw)}`;
  await sendEmail(user.email, "Verify your V3rya email", `<p>Welcome to V3rya.</p><p><a href="${url}">Verify your email address</a>. This link expires in 24 hours.</p>`);
}

export async function sendResetEmail(user: { id: number; email: string }) {
  const raw = createToken();
  await db.createEmailToken({ userId: user.id, tokenHash: tokenHash(raw), type: "reset", expiresAt: new Date(Date.now() + 1000 * 60 * 30) });
  const url = `${ENV.appUrl.replace(/\/$/, "")}/auth/reset?token=${encodeURIComponent(raw)}`;
  await sendEmail(user.email, "Reset your V3rya password", `<p><a href="${url}">Reset your password</a>. This link expires in 30 minutes.</p>`);
}

export async function register(input: { email: string; password: string; name?: string }) {
  const email = emailSchema.parse(input.email);
  enforceAuthRateLimit(`register:${email}`);
  if (!passwordIsStrong(input.password)) throw new TRPCError({ code: "BAD_REQUEST", message: "Password must be at least 10 characters and include uppercase, lowercase, and a number." });
  if (await db.getUserByEmail(email)) throw new TRPCError({ code: "CONFLICT", message: "An account with that email already exists." });
  const user = await db.createUser({ email, passwordHash: await hashPassword(input.password), name: input.name?.trim() || null, role: email === ENV.adminEmail ? "admin" : "user" });
  if (!user) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Could not create account." });
  await sendVerificationEmail(user);
  const checkoutUrl = ENV.registrationFeeCents > 0 ? await createRegistrationCheckout(user) : null;
  return { userId: user.id, requiresPayment: ENV.registrationFeeCents > 0, checkoutUrl };
}

export async function login(emailInput: string, password: string) {
  const email = emailSchema.parse(emailInput);
  enforceAuthRateLimit(`login:${email}`);
  const user = await db.getUserByEmail(email);
  if (!user || !(await verifyPassword(password, user.passwordHash))) throw new TRPCError({ code: "UNAUTHORIZED", message: "Email or password is incorrect." });
  if (user.accountStatus === "suspended") throw new TRPCError({ code: "FORBIDDEN", message: "This account has been suspended." });
  if (!user.emailVerifiedAt) throw new TRPCError({ code: "FORBIDDEN", message: "Please verify your email before signing in." });
  if (user.membershipStatus !== "active") throw new TRPCError({ code: "FORBIDDEN", message: "Complete registration payment before signing in." });
  await db.touchLastSignedIn(user.id);
  return { token: await createSessionToken(user.id) };
}

export async function verifyEmail(rawToken: string) {
  const token = await db.consumeEmailToken(tokenHash(rawToken), "verify");
  if (!token) throw new TRPCError({ code: "BAD_REQUEST", message: "That verification link is invalid or expired." });
  await db.markEmailVerified(token.userId);
}

export async function resendVerification(emailInput: string) {
  const email = emailSchema.parse(emailInput);
  const user = await db.getUserByEmail(email);
  if (user && !user.emailVerifiedAt) await sendVerificationEmail(user);
  return { success: true };
}

export async function requestPasswordReset(emailInput: string) {
  const email = emailSchema.parse(emailInput);
  const user = await db.getUserByEmail(email);
  if (user) await sendResetEmail(user);
  return { success: true };
}

export async function resetPassword(rawToken: string, password: string) {
  if (!passwordIsStrong(password)) throw new TRPCError({ code: "BAD_REQUEST", message: "Password must be at least 10 characters and include uppercase, lowercase, and a number." });
  const token = await db.consumeEmailToken(tokenHash(rawToken), "reset");
  if (!token) throw new TRPCError({ code: "BAD_REQUEST", message: "That reset link is invalid or expired." });
  await db.setPassword(token.userId, await hashPassword(password));
}
