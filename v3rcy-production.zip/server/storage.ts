import { GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { ENV } from "./_core/env";

const client = new S3Client({ region: ENV.s3Region, ...(ENV.s3Endpoint ? { endpoint: ENV.s3Endpoint, forcePathStyle: true } : {}) });

export async function storagePut(key: string, data: Buffer, contentType: string) {
  if (!ENV.s3Bucket) throw new Error("Object storage is not configured.");
  await client.send(new PutObjectCommand({ Bucket: ENV.s3Bucket, Key: key, Body: data, ContentType: contentType, CacheControl: "public, max-age=31536000, immutable" }));
  const url = ENV.s3PublicBaseUrl ? `${ENV.s3PublicBaseUrl.replace(/\/$/, "")}/${key.split("/").map(encodeURIComponent).join("/")}` : await getSignedUrl(client, new GetObjectCommand({ Bucket: ENV.s3Bucket, Key: key }), { expiresIn: 3600 });
  return { key, url };
}
