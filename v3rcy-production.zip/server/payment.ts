import crypto from "node:crypto";
import * as db from "./db";
import { ENV } from "./_core/env";

async function stripeRequest(path: string, body: URLSearchParams) {
  if (!ENV.stripeSecretKey) throw new Error("Stripe is not configured.");
  const response = await fetch(`https://api.stripe.com/v1/${path}`, { method: "POST", headers: { Authorization: `Bearer ${ENV.stripeSecretKey}`, "Content-Type": "application/x-www-form-urlencoded" }, body });
  const data = await response.json() as any;
  if (!response.ok) throw new Error(data?.error?.message || "Stripe request failed.");
  return data;
}

export async function createRegistrationCheckout(user: { id: number; email: string }) {
  if (!ENV.stripeSecretKey) throw new Error("Payments are not configured.");
  const body = new URLSearchParams();
  body.set("mode", "payment");
  body.set("success_url", `${ENV.appUrl.replace(/\/$/, "")}/auth/payment-success?session_id={CHECKOUT_SESSION_ID}`);
  body.set("cancel_url", `${ENV.appUrl.replace(/\/$/, "")}/auth/payment-cancelled`);
  body.set("customer_email", user.email);
  body.set("line_items[0][quantity]", "1");
  body.set("line_items[0][price_data][currency]", ENV.stripeCurrency);
  body.set("line_items[0][price_data][unit_amount]", String(ENV.registrationFeeCents));
  body.set("line_items[0][price_data][product_data][name]", "V3rya membership registration");
  body.set("metadata[user_id]", String(user.id));
  const session = await stripeRequest("checkout/sessions", body);
  await db.createRegistrationPayment({ userId: user.id, stripeSessionId: session.id, amountCents: ENV.registrationFeeCents, currency: ENV.stripeCurrency });
  return session.url as string;
}

export function verifyStripeSignature(rawBody: Buffer, signatureHeader: string | undefined) {
  if (!signatureHeader || !ENV.stripeWebhookSecret) return false;
  const timestamp = signatureHeader.split(",").find(part => part.startsWith("t="))?.slice(2);
  const signatures = signatureHeader.split(",").filter(part => part.startsWith("v1=")).map(part => part.slice(3));
  if (!timestamp || !signatures.length) return false;
  const age = Math.abs(Math.floor(Date.now() / 1000) - Number(timestamp));
  if (!Number.isFinite(age) || age > 300) return false;
  const signed = `${timestamp}.${rawBody.toString("utf8")}`;
  const expected = crypto.createHmac("sha256", ENV.stripeWebhookSecret).update(signed).digest("hex");
  return signatures.some(signature => signature.length === expected.length && crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected)));
}
