# V3rya production checklist

## Required services
- MySQL 8+
- Stripe Checkout + webhook endpoint at `/api/stripe/webhook`
- Transactional email provider via Resend
- S3-compatible object storage
- HTTPS reverse proxy

## Required secrets
See `.env.example`. Never commit `.env` or production secrets.

## Admin
Set `ADMIN_EMAIL` to the one email address that should receive the administrator role. There is no admin promotion endpoint in the application.

## Registration
Registration creates a pending account, sends email verification, and creates a Stripe Checkout session for the configured one-time fee. The account becomes active only after both the Stripe webhook confirms payment and the email is verified.

## Database
Run `pnpm db:push` against a fresh database, and review generated SQL before applying changes to an existing database.

## Security notes
- Passwords use Node's scrypt implementation.
- Authentication uses an HTTP-only SameSite cookie containing a signed session token.
- Stripe payment state is changed only by a verified webhook.
- Admin procedures are authorized server-side.
- Post/comment/reaction writes are rate-limited.
- Uploads validate MIME type, magic bytes, size, and an ownership attestation.
