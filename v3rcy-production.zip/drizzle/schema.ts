import { boolean, index, int, json, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull(),
  name: text("name"),
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  emailVerifiedAt: timestamp("emailVerifiedAt"),
  membershipStatus: mysqlEnum("membershipStatus", ["pending_payment", "paid_unverified", "active"]).default("pending_payment").notNull(),
  accountStatus: mysqlEnum("accountStatus", ["active", "suspended"]).default("active").notNull(),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
}, (table) => [uniqueIndex("users_email_unique").on(table.email)]);

export const emailTokens = mysqlTable("emailTokens", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  tokenHash: varchar("tokenHash", { length: 64 }).notNull().unique(),
  type: mysqlEnum("type", ["verify", "reset"]).notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  usedAt: timestamp("usedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("email_tokens_user_type_idx").on(table.userId, table.type)]);

export const registrationPayments = mysqlTable("registrationPayments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  stripeSessionId: varchar("stripeSessionId", { length: 255 }).notNull().unique(),
  amountCents: int("amountCents").notNull(),
  currency: varchar("currency", { length: 8 }).notNull(),
  status: mysqlEnum("status", ["pending", "paid", "failed", "refunded"]).default("pending").notNull(),
  paidAt: timestamp("paidAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("registration_payments_user_idx").on(table.userId), index("registration_payments_status_idx").on(table.status)]);

export const posts = mysqlTable("posts", {
  id: int("id").autoincrement().primaryKey(),
  authorUserId: int("authorUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
  body: text("body").notNull(),
  imageUrl: varchar("imageUrl", { length: 768 }),
  commentsEnabled: boolean("commentsEnabled").default(true).notNull(),
  visibility: mysqlEnum("visibility", ["published", "removed"]).default("published").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("posts_author_created_idx").on(table.authorUserId, table.createdAt), index("posts_visibility_created_idx").on(table.visibility, table.createdAt)]);

export const postComments = mysqlTable("postComments", {
  id: int("id").autoincrement().primaryKey(),
  postId: int("postId").notNull().references(() => posts.id, { onDelete: "cascade" }),
  authorUserId: int("authorUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
  body: text("body").notNull(),
  visibility: mysqlEnum("visibility", ["visible", "removed"]).default("visible").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("post_comments_post_created_idx").on(table.postId, table.createdAt), index("post_comments_author_idx").on(table.authorUserId)]);

export const postReactions = mysqlTable("postReactions", {
  id: int("id").autoincrement().primaryKey(),
  postId: int("postId").notNull().references(() => posts.id, { onDelete: "cascade" }),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  emoji: varchar("emoji", { length: 16 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("post_reactions_user_post_unique").on(table.postId, table.userId), index("post_reactions_post_idx").on(table.postId)]);

export const userProfiles = mysqlTable("userProfiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  displayName: varchar("displayName", { length: 48 }),
  bio: text("bio"),
  age: int("age").notNull(),
  city: varchar("city", { length: 80 }).notNull(),
  preferences: json("preferences").$type<string[]>().notNull(),
  verificationStatus: mysqlEnum("verificationStatus", ["none", "email", "id"]).default("none").notNull(),
  accountStatus: mysqlEnum("accountStatus", ["active", "review", "suspended"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("user_profiles_user_unique").on(table.userId), index("user_profiles_city_idx").on(table.city)]);

export const listings = mysqlTable("listings", {
  id: int("id").autoincrement().primaryKey(),
  ownerUserId: int("ownerUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 120 }).notNull(),
  description: text("description").notNull(),
  category: mysqlEnum("category", ["dating", "companionship", "casual", "social"]).notNull(),
  city: varchar("city", { length: 80 }).notNull(),
  verificationRequired: mysqlEnum("verificationRequired", ["none", "email", "id"]).default("none").notNull(),
  visibility: mysqlEnum("visibility", ["live", "removed", "archived"]).default("live").notNull(),
  moderationStatus: mysqlEnum("moderationStatus", ["unreviewed", "approved", "flagged", "rejected"]).default("unreviewed").notNull(),
  publishedAt: timestamp("publishedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("listings_visibility_city_idx").on(table.visibility, table.city), index("listings_owner_idx").on(table.ownerUserId)]);

export const profileMedia = mysqlTable("profileMedia", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  storageKey: varchar("storageKey", { length: 512 }).notNull().unique(),
  url: varchar("url", { length: 768 }).notNull(),
  mediaType: mysqlEnum("mediaType", ["image", "video"]).notNull(),
  mimeType: varchar("mimeType", { length: 80 }).notNull(),
  caption: varchar("caption", { length: 180 }),
  visibility: mysqlEnum("visibility", ["public", "hidden"]).default("public").notNull(),
  isFeatured: boolean("isFeatured").default(false).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("profile_media_user_idx").on(table.userId, table.sortOrder, table.createdAt)]);

export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  threadKey: varchar("threadKey", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("conversations_thread_key_unique").on(table.threadKey)]);

export const conversationParticipants = mysqlTable("conversationParticipants", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull().references(() => conversations.id, { onDelete: "cascade" }),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  joinedAt: timestamp("joinedAt").defaultNow().notNull(),
}, (table) => [uniqueIndex("conversation_participants_unique").on(table.conversationId, table.userId), index("conversation_participants_user_idx").on(table.userId)]);

export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull().references(() => conversations.id, { onDelete: "cascade" }),
  senderUserId: int("senderUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
  body: text("body").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("messages_conversation_idx").on(table.conversationId, table.createdAt)]);

export const safetySignals = mysqlTable("safetySignals", {
  id: int("id").autoincrement().primaryKey(),
  reporterUserId: int("reporterUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
  subjectUserId: int("subjectUserId").references(() => users.id, { onDelete: "cascade" }),
  listingId: int("listingId").references(() => listings.id, { onDelete: "set null" }),
  signalType: mysqlEnum("signalType", ["safe_contact", "safety_alert"]).notNull(),
  note: text("note"),
  status: mysqlEnum("status", ["received", "under_review", "resolved"]).default("received").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("safety_signals_status_idx").on(table.status)]);

export const reports = mysqlTable("reports", {
  id: int("id").autoincrement().primaryKey(),
  reporterUserId: int("reporterUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
  subjectUserId: int("subjectUserId").references(() => users.id, { onDelete: "set null" }),
  listingId: int("listingId").references(() => listings.id, { onDelete: "set null" }),
  category: mysqlEnum("category", ["harassment", "misrepresentation", "prohibited_content", "underage_concern", "safety_concern", "other"]).notNull(),
  detail: text("detail").notNull(),
  status: mysqlEnum("status", ["received", "under_review", "action_taken", "closed"]).default("received").notNull(),
  reporterUpdate: text("reporterUpdate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("reports_status_idx").on(table.status)]);

export const moderationActions = mysqlTable("moderationActions", {
  id: int("id").autoincrement().primaryKey(),
  adminUserId: int("adminUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
  listingId: int("listingId").references(() => listings.id, { onDelete: "set null" }),
  reportId: int("reportId").references(() => reports.id, { onDelete: "set null" }),
  targetUserId: int("targetUserId").references(() => users.id, { onDelete: "set null" }),
  actionType: varchar("actionType", { length: 80 }).notNull(),
  note: text("note"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("moderation_actions_admin_idx").on(table.adminUserId, table.createdAt)]);

export const actionRateLimits = mysqlTable("actionRateLimits", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  actionType: mysqlEnum("actionType", ["listing", "message", "report", "safety", "post", "comment", "reaction"]).notNull(),
  windowStartedAt: timestamp("windowStartedAt").notNull(),
  actionCount: int("actionCount").default(0).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("action_rate_limits_user_action_unique").on(table.userId, table.actionType), index("action_rate_limits_window_idx").on(table.windowStartedAt)]);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
