# Database setup

This project uses Drizzle ORM with MySQL.

For a new deployment, configure `DATABASE_URL` and run:

```bash
pnpm db:push
```

Review the generated SQL in your deployment pipeline before applying schema changes to an existing production database. The authentication model in this release intentionally replaces the previous external-auth identity model; existing external-auth accounts cannot be logged into without a migration that establishes local passwords.
